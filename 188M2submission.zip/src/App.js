import './App.css';
import {useRef, useState, usevalue} from "react";
import React from 'react';
import { useLongPress } from 'use-long-press';



const OneDollar = require('one-dollar')
 
const recognize = OneDollar()
 
const result = recognize([[1, 2], [10, 3], [12, 27], [3, 25], [0, 0]])
 
console.log(result)

function App() {
  const MouseDown = useRef(false)
  const pointList = useRef([])
  const[text, setText] = useState("")  //const defines a constant-ish variable
  const[Page, setPage] = useState(0);
  const[show, setShow] = useState("");
  const[SHIFT, setSHIFT] = useState(0); //0 is UpperCase, 1 is LowerCase
  const bind = useLongPress((event)=>{setShow(event.target.dataset.index)},{
    onFinish: event => {setShow("")
      setText(text+event.currentTarget.dataset.index)
      console.log("HELD")},
    onCancel: event => {setShow("")
      if(SHIFT == 0){
      setText(text+event.currentTarget.dataset.parent)
      }
      else{
        setText(text+event.currentTarget.dataset.lower) //change when add lowercase
      }},
    threshold: 500,
    captureEvent: true,
    detect: 'both', //type normal letter
  })
  
  return (
    <div className="App" onMouseUp={()=>{MouseDown.current=false; console.log(pointList); 
      if(pointList.current.length >= 15) {
        const x = recognize(pointList.current).name;
        console.log(x);
        switch(x){
          case("caret"):
          setText(text+String.fromCodePoint(0x1F641));
          
          break;
          case("star"):
          setText(text+String.fromCodePoint(0x2B50));
          
          break;
          case("arrow"):
          setText(text+String.fromCodePoint(0x1F3F9));

          break;
          case("circle"):
          setText(text+String.fromCodePoint(0x1F62F));

          break;
          case("v"):
          setText(text+String.fromCodePoint(0x1F603));

          break;
          default:
        } 
      }; 
      pointList.current = []
    }}>
      <div className = "Display">
        {text}
      </div>
      <div className="keyboard" onMouseDown={()=>{MouseDown.current=true}} onMouseMove={(event)=>{
        if(MouseDown.current === true){pointList.current.push([event.clientX, event.clientY])}
      }} >
        {Page == 0?
        <div className="Page1">
          {/* direction Buttons */}
          <button className = "dirButtonL" onClick={()=>{if(Page === 0){setPage(2)} else if(Page === 1){setPage(0)} else if(Page === 2){setPage(1)}}}>
          QVJWYKZX
          </button>
          
          <button className ="upButton">
            #
          </button>

          <button className = "dirButtonR" onClick={()=>{if(Page === 0){setPage(1)} else if(Page === 1){setPage(2)} else if(Page === 2){setPage(0)}}}>
          BUHPCDGMF
          </button>
            
          <br></br>  
          
          {/* Top Row */}
          <button data-parent= "L" data-lower ="l" data-index="!" {...bind} >
            {SHIFT == 0 ?
            "L"
            :
            "l"}
            <br></br>
            <span>!</span>
            {show == "!" ?
            <div className="heldButton">
            !
            </div>
            : null}
          </button>
    {/* {...LPress} == onMouseDown={LPress.onMouseDown}onMouseUp={LPress.onMouseUp}, basically call the Lpress version */}
            <button data-parent= "O" data-lower="o" data-index="?" {...bind} >
            {SHIFT == 0 ?
            "O"
            :
            "o"}
            <br></br>
            <span>?</span>
            {show == "?" ?
            <div className="heldButton">
            ?
            </div>
            : null}
          </button>

          <button data-parent= "N" data-lower="n" data-index="." {...bind} >
            {SHIFT == 0 ?
            "N"
            :
            "n"}
            <br></br>
            <span>.</span>
            {show == "." ?
            <div className="heldButton">
            .
            </div>
            : null}
          </button>

          <br></br>
          
          {/* middle Row */}
          <button data-parent= "R" data-lower ="r" data-index="," {...bind} >
            {SHIFT == 0 ?
            "R"
            :
            "r"}
            <br></br>
            <span>,</span>
            {show == "," ?
            <div className="heldButton">
            ,
            </div>
            : null}
          </button>
    {/* {...LPress} == onMouseDown={LPress.onMouseDown}onMouseUp={LPress.onMouseUp}, basically call the Lpress version */}
            <button data-parent= "E" data-lower="e" data-index="/" {...bind} >
            {SHIFT == 0 ?
            "E"
            :
            "e"}
            <br></br>
            <span>/</span>
            {show == "/" ?
            <div className="heldButton">
            :
            </div>
            : null}
          </button>

          <button data-parent= "A" data-lower="a" data-index=";" {...bind} >
            {SHIFT == 0 ?
            "A"
            :
            "a"}
            <br></br>
            <span>;</span>
            {show == ";" ?
            <div className="heldButton">
            ;
            </div>
            : null}
          </button>


          <br></br>

          {/* Bottom Row */}
          <button data-parent= "T" data-lower ="t" data-index=":" {...bind} >
            {SHIFT == 0 ?
            "T"
            :
            "t"}
            <br></br>
            <span>:</span>
            {show == ":" ?
            <div className="heldButton">
            :
            </div>
            : null}
          </button>
    {/* {...LPress} == onMouseDown={LPress.onMouseDown}onMouseUp={LPress.onMouseUp}, basically call the Lpress version */}
            <button data-parent= "I" data-lower="i" data-index="$" {...bind} >
            {SHIFT == 0 ?
            "I"
            :
            "i"}
            <br></br>
            <span>$</span>
            {show == "$" ?
            <div className="heldButton">
            $
            </div>
            : null}
          </button>

          <button data-parent= "S" data-lower="s" data-index="%" {...bind} >
            {SHIFT == 0 ?
            "S"
            :
            "s"}
            <br></br>
            <span>%</span>
            {show == "%" ?
            <div className="heldButton">
            %
            </div>
            : null}
          </button>

          <br>
          </br>    
          <button className ="SpaceSel" onClick={()=>setPage(4)}>

          </button>
        </div>
        
        

        : Page == 1 ?
        <div className="Page2">
        {/* direction Buttons */}
          <button className = "dirButtonL" onClick={()=>{if(Page === 0){setPage(2)} else if(Page === 1){setPage(0)} else if(Page === 2){setPage(1)}}}>
          LONREATIS
          </button>
          
          <button className ="upButton">
            #
          </button>

          <button className = "dirButtonR" onClick={()=>{if(Page === 0){setPage(1)} else if(Page === 1){setPage(2)} else if(Page === 2){setPage(0)}}}>
          QVJWYKZX
          </button>
            
          <br></br>  
          
          {/* Top Row */}
          <button data-parent= "B" data-lower ="b" data-index="^" {...bind} >
            {SHIFT == 0 ?
            "B"
            :
            "b"}
            <br></br>
            <span>^</span>
            {show == "^" ?
            <div className="heldButton">
            ^
            </div>
            : null}
          </button>
           {/* {...LPress} == onMouseDown={LPress.onMouseDown}onMouseUp={LPress.onMouseUp}, basically call the Lpress version */}
            <button data-parent= "U" data-lower="u" data-index="&" {...bind} >
            {SHIFT == 0 ?
            "U"
            :
            "u"}
            <br></br>
            <span>&</span>
            {show == "&" ?
            <div className="heldButton">
            &
            </div>
            : null}
          </button>

          <button data-parent= "H" data-lower="h" data-index="*" {...bind} >
            {SHIFT == 0 ?
            "H"
            :
            "h"}
            <br></br>
            <span>*</span>
            {show == "*" ?
            <div className="heldButton">
            *
            </div>
            : null}
          </button>

          <br></br>
          
          {/* middle Row */}
          <button data-parent= "P" data-lower ="p" data-index="(" {...bind} >
            {SHIFT == 0 ?
            "P"
            :
            "p"}
            <br></br>
            <span>(</span>
            {show == "(" ?
            <div className="heldButton">
            (
            </div>
            : null}
          </button>
    {/* {...LPress} == onMouseDown={LPress.onMouseDown}onMouseUp={LPress.onMouseUp}, basically call the Lpress version */}
            <button data-parent= "C" data-lower="c" data-index=")" {...bind} >
            {SHIFT == 0 ?
            "C"
            :
            "c"}
            <br></br>
            <span>)</span>
            {show == ")" ?
            <div className="heldButton">
            )
            </div>
            : null}
          </button>

          <button data-parent= "D" data-lower="d" data-index="-" {...bind} >
            {SHIFT == 0 ?
            "D"
            :
            "d"}
            <br></br>
            <span>-</span>
            {show == "-" ?
            <div className="heldButton">
            -
            </div>
            : null}
          </button>


          <br></br>

          {/* Bottom Row */}
          <button data-parent= "G" data-lower ="g" data-index="+" {...bind} >
            {SHIFT == 0 ?
            "G"
            :
            "g"}
            <br></br>
            <span>+</span>
            {show == "+" ?
            <div className="heldButton">
            +
            </div>
            : null}
          </button>
    {/* {...LPress} == onMouseDown={LPress.onMouseDown}onMouseUp={LPress.onMouseUp}, basically call the Lpress version */}
            <button data-parent= "M" data-lower="m" data-index="~" {...bind} >
            {SHIFT == 0 ?
            "M"
            :
            "m"}
            <br></br>
            <span>~</span>
            {show == "~" ?
            <div className="heldButton">
            ~
            </div>
            : null}
          </button>

          <button data-parent= "F" data-lower="f" data-index="'" {...bind} >
            {SHIFT == 0 ?
            "F"
            :
            "f"}
            <br></br>
            <span>'</span>
            {show == "'" ?
            <div className="heldButton">
            '
            </div>
            : null}
          </button>

          <br></br>
          <button className ="SpaceSel" onClick={()=>setPage(4)}>

          </button>
        </div>

        

        : Page == 2?
        <div className="Page3">
          {/* direction Buttons */}
          <button className = "dirButtonL" onClick={()=>{if(Page === 0){setPage(2)} else if(Page === 1){setPage(0)} else if(Page === 2){setPage(1)}}}>
            BUHPCDGMF
          </button>

          <button className ="upButton">
            #
          </button>

          <button className = "dirButtonR" onClick={()=>{if(Page === 0){setPage(1)} else if(Page === 1){setPage(2)} else if(Page === 2){setPage(0)}}}>
            LONREATIS
          </button>
            
          <br></br>  
          
          {/* Top Row */}
          <button data-parent= "Q" data-lower ="q" data-index="=" {...bind} >
            {SHIFT == 0 ?
            "Q"
            :
            "q"}
            <br></br>
            <span>=</span>
            {show == "=" ?
            <div className="heldButton">
            =
            </div>
            : null}
          </button>
   
            <button data-parent= "V" data-lower="v" data-index="[" {...bind} >
            {SHIFT == 0 ?
            "V"
            :
            "v"}
            <br></br>
            <span>[</span>
            {show == "[" ?
            <div className="heldButton">
            [
            </div>
            : null}
          </button>

          <button data-parent= "J" data-lower="j" data-index="]" {...bind} >
            {SHIFT == 0 ?
            "J"
            :
            "j"}
            <br></br>
            <span>]</span>
            {show == "]" ?
            <div className="heldButton">
            ]
            </div>
            : null}
          </button>

          <br></br>
          
          {/* middle Row */}
          <button data-parent= "W" data-lower ="w" data-index="@" {...bind} >
            {SHIFT == 0 ?
            "W"
            :
            "w"}
            <br></br>
            <span>@</span>
            {show == "@" ?
            <div className="heldButton">
            @
            </div>
            : null}
          </button>
   
            <button data-parent= "Y" data-lower="y" data-index="#" {...bind} >
            {SHIFT == 0 ?
            "Y"
            :
            "y"}
            <br></br>
            <span>#</span>
            {show == "#" ?
            <div className="heldButton">
            #
            </div>
            : null}
          </button>

          <button data-parent= "K" data-lower="k" data-index="|" {...bind} >
            {SHIFT == 0 ?
            "K"
            :
            "k"}
            <br></br>
            <span>|</span>
            {show == "|" ?
            <div className="heldButton">
            |
            </div>
            : null}
          </button>


          <br></br>

          {/* Bottom Row */}
          <button data-parent= "Z" data-lower ="x" data-index="`" {...bind} >
            {SHIFT == 0 ?
            "Z"
            :
            "z"}
            <br></br>
            <span>`</span>
            {show == "`" ?
            <div className="heldButton">
            `
            </div>
            : null}
          </button>
    
            <button data-parent= "X" data-lower="x" data-index="_" {...bind} >
            {SHIFT == 0 ?
            "X"
            :
            "x"}
            <br></br>
            <span>_</span>
            {show == "_" ?
            <div className="heldButton">
            _
            </div>
            : null}
          </button>

          <button onClick={()=>setText(text.slice(0,(text.length-1)))} >
            DEL
            <br></br>
            BACK
          </button>

          <br>
          </br>    
          <button className ="SpaceSel" onClick={()=>setPage(4)}>

          </button>
        </div>

        :
        <div className = "Page 4">
          
          <br></br>
          <br></br>
          <br></br>
          <br></br>
          <br></br>
          <br></br>
          <button className="ShiftButton" onClick={()=>{setSHIFT(!SHIFT)}}>
            SHFT
            
          
          </button>

          <button className="ShiftButton" onClick={()=>{setPage(0)}} >
            ^^^
            
          
          </button>

          <button className="ShiftButton"  onClick={()=>{setText("")}}>
            ENTR
            
          
          </button>
          <br></br>
          <button className="Shift2Button"  onClick={()=>{setText(text+" ")}}>
            SPACE
            
          
          </button>
        
        </div>
        }

      </div>
    </div>
  );
}

export default App;
